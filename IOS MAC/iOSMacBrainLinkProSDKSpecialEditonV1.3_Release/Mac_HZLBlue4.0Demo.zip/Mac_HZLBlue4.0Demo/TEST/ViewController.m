//
//  ViewController.m
//  TEST
//
//  Created by Macrotellect-iOSDev on 2018/6/27.
//  Copyright © 2018年 macrotellect. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}


@end
