//
//  AppDelegate.m
//  TEST
//
//  Created by Macrotellect-iOSDev on 2018/6/27.
//  Copyright © 2018年 macrotellect. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}


@end
