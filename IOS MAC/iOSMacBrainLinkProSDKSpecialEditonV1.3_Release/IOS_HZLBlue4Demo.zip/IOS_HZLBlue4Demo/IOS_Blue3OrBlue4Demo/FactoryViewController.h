//
//  FactoryViewController.h
//  蓝牙4.0测试
//
//  Created by Macrotellect-iOSDev on 17/5/17.
//  Copyright © 2017年 Macrotellect-iOSDev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FactoryViewController : UIViewController

@property(nonatomic,assign)int devSum;
@property(nonatomic,copy)NSArray *deviceNames;
@end

