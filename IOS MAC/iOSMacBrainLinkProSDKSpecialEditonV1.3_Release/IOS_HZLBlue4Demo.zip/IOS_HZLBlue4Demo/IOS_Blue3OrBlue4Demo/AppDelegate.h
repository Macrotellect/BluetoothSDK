//
//  AppDelegate.h
//  IOS_Blue4Demo
//
//  Created by Macrotellect-iOSDev on 2019/8/8.
//  Copyright © 2019 Macrotellect-iOSDev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

